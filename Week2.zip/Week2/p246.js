/**
 * Created by David on 2/4/2016.
 */
"use strict";
var buttonWhichClassHandler = function () {
    var selector = $("input[name=selector]").val();
    var whichClass = $(this).data('whichclass');
    // gotta be careful with data-* attributes;
    // notice that my HTML has camelCase "whichClass"
    // but the DOM normalized this to lowercase, "whichclass"!
    // That wasted about 10 minutes trying to figure out
    // what I was doing wrong! I finally had to turn on
    // the debugger and inspect "this" to figure it out.
    var elements; //don't have a value yet
    // if the selector is not a valid jQuery selector
    // an exception will be thrown. We can deal with that
    // by "try"ing to run our code and "catch"ing
    // the exception if it is thrown. An uncaught exception
    // is a bad thing... basically a program crash
    try {
        elements = $(selector);
    }
    catch (error) {
        elements = undefined;
        console.log(error.message);
    }
    // JavaScript type coercion here...
    // undefined will be considered false
    // any jQuery object is considered true
    if (elements) {
        // More coercion: empty string == false
        if (whichClass) {
            console.log("Adding style " + whichClass +
                " to " + selector);
            elements.addClass(whichClass);
        } else {
            console.log("Clearing styles from " + selector);
            elements.removeClass();
        }
    }
};

// modify the original page to add a div holding the new controls
$(function () {
    $('body').prepend('<div>Elements: <input name="selector" placeholder="jQuery Selector">' +
        '<button data-whichClass="border">Border</button>' +
        '<button data-whichClass="background">Background</button>' +
        '<button data-whichClass="border1">Dotted Border</button>' +
        '<button data-whichClass="background1">Blackout</button>' +
        '<button data-whichClass="">Clear</button>' +
        '</div>');

// jQuery makes binding functions to handlers easy:
    $('button[data-whichClass]').click(buttonWhichClassHandler); //named function
    $('button[data-whichClass=""]').dblclick(function () {
        $("*").removeClass();
    }); //an anonymous function
});

var buttonWhichEffectHandler = function () {
    var selector2 = $("input[name=selector2]").val();
    var whichEffect = $(this).data('whicheffect');
    // gotta be careful with data-* attributes;
    // notice that my HTML has camelCase "whichClass"
    // but the DOM normalized this to lowercase, "whichclass"!
    // That wasted about 10 minutes trying to figure out
    // what I was doing wrong! I finally had to turn on
    // the debugger and inspect "this" to figure it out.
    var elements; //don't have a value yet
    // if the selector is not a valid jQuery selector
    // an exception will be thrown. We can deal with that
    // by "try"ing to run our code and "catch"ing
    // the exception if it is thrown. An uncaught exception
    // is a bad thing... basically a program crash
    try {
        elements = $(selector2);
    }
    catch (error) {
        elements = undefined;
        console.log(error.message);
    }
    // JavaScript type coercion here...
    // undefined will be considered false
    // any jQuery object is considered true
    if (elements) {
        // More coercion: empty string == false
        if (whichEffect) {
            console.log("Adding style " + whichEffect +
                " to " + selector2);
            switch(whichEffect) {
                case "hide":
                    elements.hide();
                    break;
                case "show":
                    elements.show();
                default:
                    break;
            }
        } else {
            console.log("Clearing styles from " + selector2);
            elements.removeClass();
        }
    }
};

$(function () {
    $('body').prepend('<div>Elements: <input name="selector2" placeholder="jQuery Selector">' +
        '<button data-whichEffect="hide">Hide</button>' +
        '<button data-whichEffect="show">Show</button>' +
        '</div>');

    // jQuery makes binding functions to handlers easy:
    $('button[data-whichEffect]').click(buttonWhichEffectHandler); //named function
    $('button[data-whichEffect=""]').dblclick(function () {
        $("*").removeClass();
    }); //an anonymous function
});

