/**
 * Created by Cedrik on 1/28/2016.
 */
var response_hello = function(name) {
    return "Hello, " + name +
            "; Thanks for stopping by!";
};

var click_go_button = function() {
    var name = document.getElementById("name").value;
    var message = response_hello(name);
    document.getElementById("response").innerHTML = message;
};

document.getElementById("go").onclick = click_go_button;